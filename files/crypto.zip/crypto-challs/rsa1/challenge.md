# Randomly Sampled Algorithm 1
* Author: Alkalem, based on challenge of lamchcl

Can you still beat it if I dont tell you anything?