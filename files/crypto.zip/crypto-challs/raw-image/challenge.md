# raw-image
* Challenge from defcamp-ctf-2022

My friend messed up decrypting this image. Can you do it properly?

Flag format CTF{sha256}.