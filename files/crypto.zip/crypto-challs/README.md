# Crypto challenges

Eine kleine Sammlung von Crypto-Challenges aus vergangenen CTFs.
* vinegarFactory (Vigenère)
* personal_encryptor_with_nonbreakable_information_theoretic_security (OTP)
* raw-image (AES)
* rsa0 (RSA)
* rsa1 (RSA)
* rsa2 (RSA)
* ssh-bank (AES-CTR, HMAC, custom protocol)