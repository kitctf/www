# Randomly Sampled Algorithm
* Author: lamchcl for AngstromCTF

RSA strikes strikes strikes again again again!
