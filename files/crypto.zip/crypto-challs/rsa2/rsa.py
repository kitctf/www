from Crypto.Util.number import getStrongPrime
f = [REDACTED]
m = int.from_bytes(f,'big')
p = getStrongPrime(2048)
q = getStrongPrime(2048)
n = p*q
e = 3
c = pow(m,e,n)
print("n =",n)
print("e =",e)
print("c =",c)
