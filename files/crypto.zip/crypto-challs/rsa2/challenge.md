# Randomly Sampled Algorithm 2
* Author: Alkalem, based on challenge of lamchcl

Can you still beat it if I dont tell you anything?
This time, you should not even be able to factor my N.