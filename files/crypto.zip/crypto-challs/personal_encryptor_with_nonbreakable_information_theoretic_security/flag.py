
FLAG = 'ctf{It_w4s_too_good_to_b3_tru3}'