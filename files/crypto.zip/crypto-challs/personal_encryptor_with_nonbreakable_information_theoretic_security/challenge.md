# Personal Encryptor with Nonbreakable Inforation-theoretic Security
* Author: rugo|RedRocket for CyberSecurityRumble 2021

The Personal Encryptor with Nonbreakable Information-theoretic Security seems rock solid.

The PoC's code is even available: [code](main.py)
