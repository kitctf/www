#include <stdlib.h>

class CtfTeam {
    public:
        char* name;
        int points;
        char** members;
        virtual void addPoints(int p) {
            points += p;
        }
        CtfTeam(char* name, char** members) {
            this->name = name;
            this->points = 0;
            this->members = members;
        }
};
class HighSchoolTeam : public CtfTeam {
    private:
        char* schoolName;
    public:
        virtual void addPoints(int p) {
            points += p + 10;
        }
        virtual void setSchoolName(char* name) {
            schoolName = name;
        }
        HighSchoolTeam(char* name, char** members, char* schoolName)
            : CtfTeam(name, members) {
            this->schoolName = schoolName;
        }
};

int main(int argc, char** argv) {
    if (argc < 2) {
        return EXIT_FAILURE;
    }
    CtfTeam *team = new CtfTeam(argv[1], new char*[argc - 2]);
    team->addPoints(10);

    HighSchoolTeam *hst = new HighSchoolTeam(argv[1], new char*[argc - 2], argv[1]);
    hst->addPoints(10);

    return EXIT_SUCCESS;
}
