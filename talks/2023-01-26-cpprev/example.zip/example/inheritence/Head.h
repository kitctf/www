struct CtfTeamData {
    char* name;
    int points;
    char** members;
};
struct CtfTeamVTable {
    void (*addPoints)(int);
};
struct CtfTeam {
    CtfTeamVTable* vtable;
    CtfTeamData data;
};
struct HighSchoolTeamData {
    char* name;
    int points;
    char** members;
    char* schoolName;
};
struct HighSchoolTeamVTable {
    void (*addPoints)(int);
    char* (*getSchoolName)();
};
struct HighSchoolTeam {
    HighSchoolTeamVTable* vtable;
    HighSchoolTeamData data;
};
