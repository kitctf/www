#include <stdlib.h>

class CtfTeam {
    public:
        char* name;
        int points;
        char** members;
        void addPoints(int p) {
            points += p;
        }
};

int main(int argc, char** argv) {
    if (argc < 2) {
        return EXIT_FAILURE;
    }
    CtfTeam *team = new CtfTeam();
    team->name = argv[1];
    team->points = 0;
    team->members = new char*[argc - 2];
    for (int i = 2; i < argc; i++)
        team->members[i-2] = argv[i];
    team->addPoints(10);
    return EXIT_SUCCESS;
}
