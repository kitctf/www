from dataclasses import dataclass
from typing import List


@dataclass
class CtfTeam:
    name: str
    points: int
    members: List[str]

    def add_points(self, points):
        self.points += points


team = CtfTeam(name="FlawedGreen", points=0, members=["..."])
# equivalent to team.add_points(50)
team.__getattribute__("add_points").__func__(team, 50)
print(team.points)
