# SecureSlot

For software to be secure it needs to be running on the blockchain.
Here at the KAsino Royal we take security very seriously, thats why our new SlotMachine is using 100% secure blockchain technology.

Challenge interface: `nc localhost 20000`
Faucet: http://localhost:8080
RPC: http://localhost:8545 ChainId: 25718
Webapp: http://localhost:41337
